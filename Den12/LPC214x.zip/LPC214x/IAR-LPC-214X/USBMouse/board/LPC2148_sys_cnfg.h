#ifndef __LPC2148_SYS_CNFG_H
#define __LPC2148_SYS_CNFG_H

/***************************************************************************
 **
 **    This file defines the board specific definition
 **    NXP LPC2148
 **
 **    Used with ARM IAR C/C++ Compiler and Assembler.
 **
 **    (c) Copyright IAR Systems 2005
 **
 **    $Revision: 7689 $
 **
 ***************************************************************************/

/* OSC [Hz] */
#define FOSC                12000000UL

/* Core clk [Hz]  > 18 MHz */
#define FCCLK               (12000000UL*2)

/* Time Precision time [us] */
#define TIMER_PRECISION     1

/* Sys timer tick per seconds */
#define TICK_PER_SECOND     100

/* Max Adc frequency [Hz]*/
#define MAX_ADC_FREQ      4500000

#endif /* __LPC2148_SYS_CNFG_H */
