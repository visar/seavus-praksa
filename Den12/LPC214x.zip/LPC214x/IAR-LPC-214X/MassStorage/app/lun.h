/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2005
 *
 *    File name   : lun.h
 *    Description : LUN common definitions module
 *
 *    History :
 *    1. Date        : November 15, 2005
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 14946 $
 **************************************************************************/
#include "arm_comm.h"
#include "includes.h"

#ifndef __LUN_H
#define __LUN_H

#ifdef  LUN_GOBALS
#define LUN_EXTERN
#else
#define LUN_EXTERN extern
#endif

typedef enum
{
  LunCommandDecode = 0, LunRead, LunWrite, LunVerify
} LunState_t;

typedef enum
{
  LunInitMsg = 0, LunResetReqMsg, LunInquiryReqMsg,
  LunTestUntilReadyReqMsg,LunModeSense6ReqMsg, LunReadCapacity10ReqMsg,
  LunRead10ReqMsg, LunWrite10ReqMsg,
  LunVerify10ReqMsg, LunVerify10BytChkReqMsg,
  LunReadFormatCapacityReqMsg,
  LunDataReadyMsg
} LunMessages_t;

typedef struct
{
  DiskInitFpnt_t   DiskInitFpnt;
  DiskInfoFpnt_t   DiskInfoFpnt;
  DiskStatusFpnt_t DiskStatusFpnt;
  DiskIoFpnt_t     DiskIoFpnt;
} LunFpnt_t, *pLunFpnt_t;

/*************************************************************************
 * Function Name: LunInit
 * Parameters: Int32U LunInd,
 *             DiskInitFpnt_t DiskInitFpnt, DiskInfoFpnt_t DiskInfoFpnt,
 *             DiskStatusFpnt_t DiskStatusFpnt, DiskIoFpnt_t, DiskIoFpnt
 *
 * Return: none
 *
 * Description: LUN Init
 *
 *************************************************************************/
void LunInit (Int32U LunInd,
              DiskInitFpnt_t DiskInitFpnt, DiskInfoFpnt_t DiskInfoFpnt,
              DiskStatusFpnt_t DiskStatusFpnt, DiskIoFpnt_t DiskIoFpnt);

/*************************************************************************
 * Function Name: LunImp
 * Parameters:  Int32U DiskInd
 *
 * Return: none
 *
 * Description: LUN commands implementation
 *
 *************************************************************************/
void LunImp (Int32U DiskInd);

#endif //__LUN_H
