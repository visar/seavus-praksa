/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2003
 *
 *    File name      : hid_mouse.c
 *    Description    : Define HID module
 *
 *    History :
 *    1. Date        : December 19, 2005
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 14946 $
**************************************************************************/
#include "hid_mouse.h"

#pragma data_alignment=4
Int8U DataBuffer[sizeof(UsbHidDescriptor_t)];
#pragma data_alignment=4
MouseReport_t MouseReport = {0,0,0};


/*************************************************************************
 * Function Name: HidInit
 * Parameters: none
 *
 * Return: none
 *
 * Description: Init HID Mouse
 *
 *************************************************************************/
void HidInit (void)
{
  MouseReport.Buttons = 0;
  MouseReport.X = 0;
  MouseReport.Y = 0;
  UsbCoreUserFuncRegistering(UsbClassHidDescriptor,UsbUserGetDescriptor);
  UsbCoreUserFuncRegistering(UsbClassHidRequest,UsbUserClass);
}

/*************************************************************************
 * Function Name: UsbClassHidConfigure
 * Parameters:  void * pArg
 *
 * Return: void *
 *
 * Description: USB Class HID configure
 *
 *************************************************************************/
void * UsbClassHidConfigure (void * pArg)
{
  if((Int32U)pArg == 0)
  {
    if(UsbCoreReq(UsbCoreReqConfiquration) != 0)
    {
      // disable all class EPs
      USB_RealizeEndPoint((USB_Endpoint_t)ReportEp ,1,0,FALSE);
      USB_UserFuncRegistering(NULL,ReportEp);
    }
  }
  else
  {
    // Realize Class EPs
    USB_RealizeEndPoint((USB_Endpoint_t)ReportEp ,1,ReportEpMaxSize, TRUE);
  }
  return(NULL);
}

/*************************************************************************
 * Function Name: UsbClassHidDescriptor
 * Parameters:  void * pArg
 *
 * Return: void *
 *
 * Description: Implement GET DESCRIPTOR
 *
 *************************************************************************/
void * UsbClassHidDescriptor (void * pArg)
{
UsbEpCtrl_t * UsbEp = (UsbEpCtrl_t *) pArg;
UsbSetupPacket_t * pData = (UsbSetupPacket_t *) UsbEp->pData;
  if (pData->wIndex.Word == 0)
  {
    switch (pData->wValue.Hi)
    {
    case Hid:
      UsbEp->Counter = SIZE_OF_HID_DESC;
      UsbEp->pData = (pInt8U)UsbHidDescriptor;
      return((void *)UsbUserSendPacket);
    case HidReport:
      UsbEp->Counter = SIZE_OF_HID_MOUSE_DESC;
      UsbEp->pData = (pInt8U)mouseDescriptor;
      return((void *)UsbUserSendPacket);
    }
  }
  return((void *)UsbUserStallCtrlEp);
}

/*************************************************************************
 * Function Name: UsbClassHidRequest
 * Parameters:  void * pArg
 *
 * Return: void *
 *
 * Description: Implement USB Class Hid requests
 *
 *************************************************************************/
void * UsbClassHidRequest (void * pArg)
{
UsbEpCtrl_t * UsbEp = (UsbEpCtrl_t *) pArg;
UsbSetupPacket_t *pData = (UsbSetupPacket_t *)UsbEp->pData;
  switch (pData->bRequest)
  {
  case HID_GET_REPORT:
    if((pData->wValue.Hi == 1) &&
       (pData->wIndex.Word == 1))
    {
      // Send report
      UsbEp->pData = (Int8U *)&MouseReport;
      UsbEp->Counter = ReportEpMaxSize;
      return((void *)UsbUserSendPacket);
    }
    break;
  }
  return((void *)UsbUserStallCtrlEp);
}

/*************************************************************************
 * Function Name: HidSendReport
 * Parameters:  Int8U Buttons, Int8S X Int8S Y
 *
 * Return: none
 *
 * Description: USB HID report send
 *
 *************************************************************************/
void HidSendReport (Int8U Buttons, Int8S X, Int8S Y)
{
  MouseReport.Buttons = Buttons;
  MouseReport.X = X;
  MouseReport.Y = Y;
  USB_EpWrite((USB_Endpoint_t)ReportEp,(Int32U *)&MouseReport,ReportEpMaxSize);
}
