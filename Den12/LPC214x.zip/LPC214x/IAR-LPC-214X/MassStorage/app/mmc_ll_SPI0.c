
/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2003
 *
 *    File name   : mmc_ll_spi0.h
 *    Description : SPI0 driver
 *
 *    History :
 *    1. Date        : July 1, 2005
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 14946 $
**************************************************************************/

// Hardware depend definitions
/*************************************************************************
 * Function Name: MmcChipSelect
 * Parameters: Boolean Select
 * Return: none
 *
 * Description: Mmc Chip select control
 * Select = true  - Chip is enable
 * Select = false - Chip is disable
 *
 *************************************************************************/
void MmcChipSelect (Boolean Select)
{
  if (Select)
  {
    IO0CLR_bit.P0_7 = 1;
  }
  else
  {
    IO0SET_bit.P0_7 = 1;
  }
}
/*************************************************************************
 * Function Name: MmcPresent
 * Parameters: none
 * Return: Boolean - true cart present
 *                 - false cart no present
 *
 * Description: Mmc precent check
 *
 *************************************************************************/
inline
Boolean MmcPresent (void)
{
  return(true);
}

/*************************************************************************
 * Function Name: MmcWriteProtect
 * Parameters: none
 * Return: Boolean - true cart is protected
 *                 - false cart no protected
 *
 * Description: Mmc Write protect check
 *
 *************************************************************************/
inline
Boolean MmcWriteProtect (void)
{
  return(FALSE);
}

/*************************************************************************
 * Function Name: MmcSetClockFreq
 * Parameters: Int32U Frequency
 * Return: Int32U
 *
 * Description: Set SPI ckl frequency
 *
 *************************************************************************/
Int32U MmcSetClockFreq (Int32U Frequency)
{
Int32U Div;
Int32U SysFreq = SYS_GetFpclk();
  for(Div = 8; Div < 254; Div+=2)
  {
    if(Frequency * Div > SysFreq)
    {
      break;
    }
  }
  S0SPCCR_bit.COUNTER = Div;
  // Return real frequency
  return(SYS_GetFpclk()/Div);
}
/*************************************************************************
 * Function Name: MmcInit
 * Parameters: none
 * Return: int
 * 0 - no error
 * 1 - speed is to high
 *
 * Description: Init SPI, Cart Present, Write Protect and Chip select pins
 *
 *************************************************************************/
void MmcInit (void)
{
  // Chip select
  IO0SET_bit.P0_7  = 1;
  IO0DIR_bit.P0_7  = 1;
  // Cart present
  // Spi init
  PM_OpenPeripheral(PC_PCSPI0);
  S0SPCR = 0x0824;
  // Clock Freq. Identification Mode < 400kHz
  MmcSetClockFreq(IdentificationModeClock);
  PINSEL0_bit.P0_4 = PINSEL0_bit.P0_5 = PINSEL0_bit.P0_6 = 1;
  PINSEL0_bit.P0_7 = 0;
}

/*************************************************************************
 * Function Name: MmcTranserByte
 * Parameters: Int8U ch
 * Return: Int8U
 *
 * Description: Read byte from SPI
 *
 *************************************************************************/
Int8U MmcTranserByte (Int8U ch)
{
  S0SPDR_bit.DATA = ch;
  while(!S0SPSR_bit.SPIF);
  return((Int8U)S0SPDR_bit.DATA);
}

/*************************************************************************
 * Function Name: MmcSendBlock
 * Parameters: pInt8U pData, Int32U Size
 *
 * Return: void
 *
 * Description: Read byte from SPI
 *
 *************************************************************************/
void MmcSendBlock (pInt8U pData, Int32U Size)
{
Int32U OutCount = Size;
  while (OutCount--)
  {
    S0SPDR_bit.DATA = *pData++;
    while(!S0SPSR_bit.SPIF);
    volatile Int32U Dummy = SSPDR_bit.DATA;
  }
}

/*************************************************************************
 * Function Name: MmcReceiveBlock
 * Parameters: pInt8U pData, Int32U Size
 *
 * Return: void
 *
 * Description: Read byte from SPI
 *
 *************************************************************************/
void MmcReceiveBlock (pInt8U pData, Int32U Size)
{
Int32U InCount = Size;
  while (InCount--)
  {
    S0SPDR_bit.DATA = 0xFF;
    while(!S0SPSR_bit.SPIF);
    *pData++ = S0SPDR_bit.DATA;
  }
}

/*************************************************************************
 * Function Name: MmcDly_1ms
 * Parameters: Int32U Delay
 * Return: none
 *
 * Description: Delay [msec]
 *
 *************************************************************************/
void MmcDly_1ms (Int32U Delay)
{
volatile Int32U i;
  for(;Delay;--Delay)
  {
    for(i = MMC_DLY_1MSEC;i;--i);
  }
}
