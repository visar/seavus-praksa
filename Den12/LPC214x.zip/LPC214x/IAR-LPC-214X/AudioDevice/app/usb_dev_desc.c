/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2005
 *
 *    File name   : usb_desc.c
 *    Description : usb decriptors module
 *
 *    $Revision: 14946 $
 **************************************************************************/
#include "usb_dev_desc.h"

#pragma data_alignment=4
const UsbStandardDeviceDescriptorStr_t UsbStandardDeviceDescriptorStr =
{
  sizeof(UsbStandardDeviceDescriptorStr_t),
  UsbDescriptorDevice,
  0x0110,
  0,
  0,
  0,
  Ep0MaxSize,
  0xFFFF,
  0x0003,
  0x0000,
  iManufacturerStr,
  iProductStr,
  iSerialNumberStr,
  1,
};

#pragma data_alignment=4
const Int8U UsbStandardConfigurationDescriptor[] =
{
  // Configuration Descriptor
  sizeof(UsbStandardConfigurationDescriptor_t),
  UsbDescriptorConfiguration,
  _2BL(sizeof(UsbStandardConfigurationDescriptor_t) +
       /* Interface 0 */
       sizeof(UsbStandardInterfaceDescriptor_t) +
       sizeof(UsbClassSpecificACInterfaceDescriptor_t) + 1 +
       sizeof(UsbInputTerminalDescriptor_t) +
       sizeof(UsbOutputTerminalDescriptor_t)+
       sizeof(UsbInputTerminalDescriptor_t) +
       sizeof(UsbOutputTerminalDescriptor_t)+
       sizeof(ClassSpecFeatureUnitDescriptor_t) + 3 +
       sizeof(ClassSpecFeatureUnitDescriptor_t) + 3 +
       sizeof(ClassSpecSelectorUnitDescriptor_t)+ 2 +
       /* Interface 1 */
       sizeof(UsbStandardInterfaceDescriptor_t) +
       sizeof(UsbStandardInterfaceDescriptor_t) +
       sizeof(UsbClassSpecificASInterfaceDescriptor_t) +
       sizeof(UsbTypeIFormatTypeDescriptor_t) + 3 +
       sizeof(StandardASEndpointDescriptor_t) +
       sizeof(ClassSpecASEndpointDescriptor_t)+
       /* Interface 2 */
       sizeof(UsbStandardInterfaceDescriptor_t) +
       sizeof(UsbStandardInterfaceDescriptor_t) +
       sizeof(UsbClassSpecificASInterfaceDescriptor_t) +
       sizeof(UsbTypeIFormatTypeDescriptor_t) + 3 +
       sizeof(StandardASEndpointDescriptor_t) +
       sizeof(ClassSpecASEndpointDescriptor_t)
  ),
  3,
  1,
  0,
  UsbConfigurationCommmonAttr,
  UsbConfigPower_mA(100),

  // Interface 0 Standard AC Interface Descriptor
  sizeof(UsbStandardInterfaceDescriptor_t),
  UsbDescriptorInterface,
  0,
  0,
  0,
  UsbDeviceClassAudio,
  AUDIOCONTROL,
  PR_PROTOCOL_UNDEFINED,
  0,

  // Class-specific AC Interface Descriptor
  sizeof(UsbClassSpecificACInterfaceDescriptor_t) + 1,
  CS_INTERFACE,
  HEADER,
  _2BL(0x0100),
  _2BL(sizeof(UsbClassSpecificACInterfaceDescriptor_t) + 1 +
       sizeof(UsbInputTerminalDescriptor_t) +
       sizeof(UsbOutputTerminalDescriptor_t)+
       sizeof(UsbInputTerminalDescriptor_t) +
       sizeof(ClassSpecFeatureUnitDescriptor_t) + 3 +
       sizeof(ClassSpecFeatureUnitDescriptor_t) + 3 +
       sizeof(ClassSpecSelectorUnitDescriptor_t)+ 2 +
       sizeof(UsbOutputTerminalDescriptor_t)),
  2,
  1,
  2,

  // Input Terminal Descriptor - SPK
  sizeof(UsbInputTerminalDescriptor_t),
  CS_INTERFACE,
  INPUT_TERMINAL,
  SpkInTermID,
  _2BL(AudioUsbStreaming),
  0,
  1,
  _2BL(AUDIO_CHANNEL_M),
  0,
  0,

  // Output Terminal Descriptor - SPK
  sizeof(UsbOutputTerminalDescriptor_t),
  CS_INTERFACE,
  OUTPUT_TERMINAL,
  SpkOutTermID,
  _2BL(AudioOutputSpk),
  0,
  FeatUnit1Id,
  0,

  // Feature Unit Descriptor - SPK
  sizeof(ClassSpecFeatureUnitDescriptor_t) + 3,
  CS_INTERFACE,
  FEATURE_UNIT,
  FeatUnit1Id,
  SpkInTermID,
  1,
  FeatUnitMute+FeatUnitVolume,
  0,
  0,

  // Input Terminal Descriptor - MIC
  sizeof(UsbInputTerminalDescriptor_t),
  CS_INTERFACE,
  INPUT_TERMINAL,
  MicInTermID,
  _2BL(AudioInputMic),
  0,
  1,
  _2BL(AUDIO_CHANNEL_M),
  0,
  0,

  // Feature Unit Descriptor - MIC
  sizeof(ClassSpecFeatureUnitDescriptor_t) + 3,
  CS_INTERFACE,
  FEATURE_UNIT,
  FeatUnit2Id,
  MicInTermID,
  1,
  FeatUnitMute + FeatUnitVolume,
  0,
  0,

  // USB stream Output Terminal Descriptor - MIC
  sizeof(UsbOutputTerminalDescriptor_t),
  CS_INTERFACE,
  OUTPUT_TERMINAL,
  MicOutTermID,
  _2BL(AudioUsbStreaming),
  0,
  SelUnit1ID,
  0,

  // Selector Unit Descriptor - MIC
  sizeof(ClassSpecSelectorUnitDescriptor_t)+2,
  CS_INTERFACE,
  SELECTOR_UNIT,
  SelUnit1ID,
  1,
  FeatUnit2Id,
  0,

  // Interface 1
  // AudioStreaming Interface Descriptor
  // Zero-bandwidth Alternate Setting 0
  // Standard AS Interface Descriptor
  sizeof(UsbStandardInterfaceDescriptor_t),
  UsbDescriptorInterface,
  1,
  0,
  0,
  UsbDeviceClassAudio,
  AUDIOSTREAMING,
  PR_PROTOCOL_UNDEFINED,
  0,

  // Operational Alternate Setting 1
  // Standard AS Interface Descriptor
  sizeof(UsbStandardInterfaceDescriptor_t),
  UsbDescriptorInterface,
  1,
  1,
  1,
  UsbDeviceClassAudio,
  AUDIOSTREAMING,
  PR_PROTOCOL_UNDEFINED,
  0,

  // Class-specific AS General Interface Descriptor
  sizeof(UsbClassSpecificASInterfaceDescriptor_t),
  CS_INTERFACE,
  AS_GENERAL,
  SpkInTermID,
  2,
  _2BL(PCM),

  // USB Spk Type I Format Type Descriptor
  sizeof(UsbTypeIFormatTypeDescriptor_t)+ 3,
  CS_INTERFACE,
  FORMAT_TYPE,
  FORMAT_TYPE_I,
  1,
  SubFrameSize,
  8*SubFrameSize,
  1,
  (Int8U)(SampFreq),(Int8U)(SampFreq>>8),(Int8U)(SampFreq>>16),

  // USB SPK Standard Endpoint Descriptor
  sizeof(StandardASEndpointDescriptor_t),
  UsbDescriptorEp,
  UsbEpOut(SpkEp>>1),
  (Int8U)UsbEpTransferIsochronous + (Int8U)UsbEpSynchAdaptive,
  _2BL(SpkEpMaxSize),
  1,
  0,
  0,

  // USB SPK Class-specific Isoc. Audio Data Endpoint Descriptor
  sizeof(ClassSpecASEndpointDescriptor_t),
  CS_ENDPOINT,
  EP_GENERAL,
  0,
  0,
  _2BL(0),

  // Interface 2
  // AudioStreaming Interface Descriptor
  // Zero-bandwidth Alternate Setting 0
  // Standard AS Interface Descriptor
  sizeof(UsbStandardInterfaceDescriptor_t),
  UsbDescriptorInterface,
  2,
  0,
  0,
  UsbDeviceClassAudio,
  AUDIOSTREAMING,
  PR_PROTOCOL_UNDEFINED,
  0,

  // Operational Alternate Setting 1
  // Standard AS Interface Descriptor
  sizeof(UsbStandardInterfaceDescriptor_t),
  UsbDescriptorInterface,
  2,
  1,
  1,
  UsbDeviceClassAudio,
  AUDIOSTREAMING,
  PR_PROTOCOL_UNDEFINED,
  0,

  // Class-specific AS General Interface Descriptor
  sizeof(UsbClassSpecificASInterfaceDescriptor_t),
  CS_INTERFACE,
  AS_GENERAL,
  MicOutTermID,
  1,
  _2BL(PCM),

  // USB MIC Type I Format Type Descriptor
  sizeof(UsbTypeIFormatTypeDescriptor_t)+ 3,
  CS_INTERFACE,
  FORMAT_TYPE,
  FORMAT_TYPE_I,
  1,
  SubFrameSize,
  8*SubFrameSize,
  1,
  (Int8U)(SampFreq),(Int8U)(SampFreq>>8),(Int8U)(SampFreq>>16),

  // USB MIC Standard Endpoint Descriptor
  sizeof(StandardASEndpointDescriptor_t),
  UsbDescriptorEp,
  UsbEpIn(MicEp>>1),
  (Int8U)UsbEpTransferIsochronous + (Int8U)UsbEpSynchAsynchronous,
  _2BL(MicEpMaxSize),
  1,
  0,
  0,

  // USB Mic Class-specific Isoc. Audio Data Endpoint Descriptor
  sizeof(ClassSpecASEndpointDescriptor_t),
  CS_ENDPOINT,
  AS_GENERAL,
  0,
  0,
  _2BL(0),

  0,
};

#pragma data_alignment=4
const Int8U UsbLanguagesStr [] =
{
  // Length of LanguagesStr + 2
  6,
  // Descriptor Type
  UsbDescriptorString,
  // Languages ID
  // Languages1 ID English
  0x09,0x04,
  // Languages2 ID Bulgarian
  0x02,0x04
};

#pragma data_alignment=4
const Int8U ManufacturerStrLan1 [] =
{
  24, // length
  UsbDescriptorString,  // Descriptor
  'I',0,'A',0,'R',0,' ',0,'S',0,'y',0,'s',0,'t',0,'e',0,'m',0,'s',0 // Str
};

#pragma data_alignment=4
const Int8U ManufacturerStrLan2 [] =
{
  24, //length
  UsbDescriptorString, // Descriptor
  '�',0,'�',0,'�',0,' ',0,'�',0,'�',0,'�',0,'�',0,'�',0,'�',0,'�',0 // Str
};

#pragma data_alignment=4
const Int8U ProductStrLan1 [] =
{
  26, //length
  UsbDescriptorString, // Descriptor
  'I',0,'A',0,'R',0,' ',0,'L',0,'P',0,'C',0,'-',0,'2',0,'1',0,'4',0,'x',0, // Str
};

#pragma data_alignment=4
const Int8U ProductStrLan2 [] =
{
  26, //length
  UsbDescriptorString, // Descriptor
  '�',0,'�',0,'�',0,' ',0,'�',0,'�',0,'�',0,'-',0,'2',0,'1',0,'4',0,'�',0, // Str
};

#pragma data_alignment=4
const Int8U SerialNumberStrLan1 [] =
{
  18, //length
  UsbDescriptorString, // Descriptor
  '0',0,'0',0,'0',0,'0',0,'0',0,'0',0,'0',0,'1',0, // Str
};

const Int8U * const UsbLanguages1Strings[] =
{
  // iManufacturerStr
  ManufacturerStrLan1,
  // iProductStr
  ProductStrLan1,
  // iSerialNumberStr
  SerialNumberStrLan1,
  // Terminator
  NULL
};

const Int8U * const UsbLanguages2Strings[] =
{
  // iManufacturerStr
  ManufacturerStrLan2,
  // iProductStr
  ProductStrLan2,
  // iSerialNumberStr
  SerialNumberStrLan1,
  // Terminator
  NULL
};

const Int8U * const * const UsbString[] =
{
  UsbLanguages1Strings,
  UsbLanguages2Strings,
};

