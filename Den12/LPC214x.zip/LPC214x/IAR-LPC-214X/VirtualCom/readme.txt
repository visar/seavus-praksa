########################################################################
#
#                    VirtualCom.eww
#
#                                                   $Revision: 7689 $
#
########################################################################

DESCRIPTION
===========
 This example project shows how to use the IAR Embedded Workbench for ARM 
to develop code for the IAR-LPC-214X evaluation boards. It implements USB 
CDC (Communication Device Class) device and install it like a Virtual COM 
port. The UART1 is used for physical implementation of the RS232 port.
This example can work standalone on the IAR-LPC-214X board.

COMPATIBILITY
=============
The project is compatible with the IAR-LPC-214X evaluation board.

The project is by default configured to use the J-Link JTAG interface.


GETTING STARTED
===============
Start the IAR Embedded Workbench for ARM.
Select File->Open->Workspace...
Open the workspace file
...IAR Systems\Embedded Workbench 4.0\arm\examples\NXP\LPC214x
	\IAR-LPC-214X\VirtualCom\VirtualCom.eww

   - put the jumpers:
   	PWR_J   - depend of power source
	DBG     - present
	
   - run program
   - use the USB cable to connect the PC to USB of the Board
The first time the device is connected to the computer, Windows will 
load the driver for identified device. The Virtual COM port driver is 
in the $PROJ_DIR$\VirCOM_Driver_XP\.

CONFIGURATION
=============
The application is downloaded to the flash.
